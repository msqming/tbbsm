from django.apps import AppConfig


class RykcConfig(AppConfig):
    name = 'rykc'
